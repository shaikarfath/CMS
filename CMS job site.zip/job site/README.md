The code is deployed on Heroku and you can check the website at: https://faizan-cv-generator.herokuapp.com/
